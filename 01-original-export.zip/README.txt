Unmodified original KiCad export

None. All 10 files from the captured export folder retain original names and bytes.

A successful render and recognized outline do not validate electrical function, fabrication or assembly.

Original non-functional synthetic teaching data. Not for fabrication, procurement or assembly. There are no routed nets or validated real footprints. All-SMD geometry; no drill files are expected. Created for PCBA Partner with AI assistance, licensed under the accompanying MIT license.

See the main pack README and scenario-expectations.json for provenance, exact expected results and test scope. Public publication and third-party listing are not implied.
