%TF.GenerationSoftware,KiCad,Pcbnew,10.0.6*%
%TF.CreationDate,2026-10-04T06:19:49+08:00*%
%TF.ProjectId,pcba-partner-file-interop-teaching,70636261-2d70-4617-9274-6e65722d6669,1.0*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.6) date 2026-10-04 06:19:49*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRotRect*
0 Rectangle, with rotation*
0 The origin of the aperture is its center*
0 $1 length*
0 $2 width*
0 $3 Rotation angle, in degrees counterclockwise*
0 Add horizontal line*
21,1,$1,$2,0,0,$3*%
G04 Aperture macros list end*
%ADD10R,1.000000X1.000000*%
%ADD11RotRect,1.000000X1.000000X45.000000*%
G04 APERTURE END LIST*
D10*
%TO.C,R1*%
X4000000Y20000000D03*
X6000000Y20000000D03*
%TD*%
%TO.C,R2*%
X15000000Y19000000D03*
X15000000Y21000000D03*
%TD*%
%TO.C,U1*%
X5000000Y11000000D03*
X5000000Y9000000D03*
%TD*%
D11*
%TO.C,D1*%
X24292893Y9292893D03*
X25707107Y10707107D03*
%TD*%
M02*
