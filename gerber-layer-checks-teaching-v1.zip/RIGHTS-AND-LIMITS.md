# Origin, rights, and scope

The native Gerber exports originate from the original PCBA Partner teaching
fixture in `operations/kicad-compatibility-pack-20261004/`. Its provenance states
that the source geometry, symbol, footprint and scripts were newly authored on
2026-10-04 with AI assistance, with no copied client board or KiCad stock symbol
or footprint. The upstream MIT license is included in the snapshot and each ZIP.

This derivative pack copies those native Gerber bytes without editing them. One
case omits a single outline file; another renames bottom copper to a misleading
top-copper filename. The baseline preserves every export name and byte. New
teaching explanations and reproducibility scripts use the same MIT license.

The files have no routed nets or functional circuit. Component identifiers are
fictional, the two-pad geometry is not an approved footprint for any real part,
and no physical board, assembly, simulation or test was performed. No drill file
is expected for this fictional all-SMD geometry. This does not imply that a real
board package can omit required drills.

The current parser ignores several X2 attribute blocks. Filename-layer labels,
parsed dimensions and visible graphics do not validate copper polarity, material
stack-up, clearances, continuity, solder mask, fabrication, assembly or regulatory
compliance. The 35 x 25 mm figure describes the fixture's outline centerline,
not a measured or manufacturer-approved physical board.

Live code snapshots under `evidence/public-code/` are internal verification
artifacts and are not included in the example ZIPs. They do not gain a new license
from this pack. KiCad, the viewer dependencies, their documentation and trademarks
remain subject to their respective owners' licenses and rights.

This local pack does not imply a KiCad endorsement, accepted external-tool listing,
partner relationship, third-party citation, or SEO outcome. Original editorial
submissions and reserved EEHerald material were not copied into it.
