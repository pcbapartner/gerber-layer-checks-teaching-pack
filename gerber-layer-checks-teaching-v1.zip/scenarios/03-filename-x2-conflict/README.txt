Bottom copper disguised as a top copper filename

Rename only pcba-partner-file-interop-teaching-B_Cu.gbl to misleading-F_Cu.gtl. Its byte content and X2 Copper,L2,Bot metadata remain unchanged. The original real top-copper file remains.

Filename classification conflicts with X2 content. The current captured viewer classifies by extension/name, so it can label both copper files as top copper. This is an intentional limitation demonstration, not an expected automatic metadata warning. Duplicate .gtl files can trigger file selection; select both deliberately to reproduce.

Original non-functional synthetic teaching data. Not for fabrication, procurement or assembly. There are no routed nets or validated real footprints. All-SMD geometry; no drill files are expected. Created for PCBA Partner with AI assistance, licensed under the accompanying MIT license.

See the main pack README and scenario-expectations.json for provenance, exact expected results and test scope. Public publication and third-party listing are not implied.
