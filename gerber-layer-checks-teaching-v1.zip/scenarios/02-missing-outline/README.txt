Outline file removed from a copy

Remove only pcba-partner-file-interop-teaching-Edge_Cuts.gm1. All retained export bytes are unchanged, including the original job file.

Copper/paste/mask/silkscreen can still render. Full drawing bounds must not be reported as confirmed board dimensions. The unedited job file still references the removed outline.

Original non-functional synthetic teaching data. Not for fabrication, procurement or assembly. There are no routed nets or validated real footprints. All-SMD geometry; no drill files are expected. Created for PCBA Partner with AI assistance, licensed under the accompanying MIT license.

See the main pack README and scenario-expectations.json for provenance, exact expected results and test scope. Public publication and third-party listing are not implied.
