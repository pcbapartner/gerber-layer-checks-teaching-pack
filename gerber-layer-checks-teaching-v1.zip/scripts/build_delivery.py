from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parents[1]
sha=lambda b:hashlib.sha256(b).hexdigest()
static=json.loads((ROOT/'evidence/static-validation.json').read_text());archive=json.loads((ROOT/'evidence/package-validation.json').read_text());browser=json.loads((ROOT/'evidence/browser-validation.json').read_text())
assert static['result']==archive['result']==browser['result']=='PASS'
status={'updatedAt':datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(timespec='seconds'),'status':'LOCAL_DELIVERY_AND_DESKTOP_UI_VERIFIED_NOT_PUBLISHED','version':'gerber-layer-checks-teaching-v1','localPackageVerified':True,'browserUiVerified':True,'browserUiScope':'Three desktop 2D teaching-ZIP load outcomes, expected layer labels/counts and reported outline status. Not all controls or 3D.','published':False,'thirdPartySubmitted':False,'productionChanges':0,'externalBacklinksCreated':0,'manufacturingReady':False,'verification':{'staticParser':{'checks':len(static['checks']),'pass':sum(c['pass'] for c in static['checks']),'evidence':'evidence/static-validation.json'},'archiveIntegrity':{'checks':len(archive['checks']),'pass':sum(c['pass'] for c in archive['checks']),'evidence':'evidence/package-validation.json'},'desktopUiEvidence':{'checks':len(browser['checks']),'pass':sum(c['pass'] for c in browser['checks']),'evidence':'evidence/browser-validation.json'}},'knownLimits':['Captured parser ignores X2 TF/TA/TD metadata blocks: 81, 74 and 81 warnings in the three scenarios.','Filename classifier labels misleading-F_Cu.gtl as top copper despite its Copper,L2,Bot content.','No functional circuit, routed nets, real components, manufacture or physical assembly test.'],'deliveryZip':'downloads/gerber-layer-checks-teaching-v1.zip'}
(ROOT/'STATUS.json').write_text(json.dumps(status,ensure_ascii=False,indent=2)+'\n')
files=[ROOT/n for n in ['README.md','RIGHTS-AND-LIMITS.md','LICENSE','STATUS.json','scenario-expectations.json','scenario-manifest.json']]
files+=sorted((ROOT/'scripts').glob('*.py'))+sorted((ROOT/'scripts').glob('*.mjs'))
files+=[ROOT/'downloads'/n for n in ['01-original-export.zip','02-missing-outline.zip','03-filename-x2-conflict.zip']]
for d in ['scenarios','source-snapshot/gerber','source-snapshot/native-source']:
 files+=sorted(p for p in (ROOT/d).rglob('*') if p.is_file())
files+=[ROOT/'source-snapshot'/n for n in ['LICENSE','upstream-rights-and-limits.md','independent-source-expectations.json','provenance.json','native-source-provenance.json','native-gerber-export-command.json']]
files+=[ROOT/'evidence'/n for n in ['static-validation.json','package-validation.json','browser-validation.json','test-asset-pins.json']]
files+=sorted((ROOT/'evidence').glob('browser-*.txt'))+sorted((ROOT/'evidence').glob('browser-*.jpg'))
files+=sorted((ROOT/'evidence/static-renders').rglob('*.svg'))
files=sorted(set(files),key=lambda p:str(p.relative_to(ROOT)))
assert all(p.exists() for p in files)
assert not any('public-code' in p.relative_to(ROOT).parts for p in files)
assert not any(p.suffix=='.kicad_prl' or p.name=='native-export-commands.json' for p in files)
manifest={'version':'gerber-layer-checks-teaching-v1','scope':'Original teaching source, controlled scenarios, three example ZIPs, notes, results and original scripts. Copied full production parser/classifier/HTML are excluded.','files':[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in files]}
(ROOT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
(ROOT/'SHA256SUMS').write_text(''.join(f['sha256']+'  '+f['path']+'\n' for f in manifest['files']))
files += [ROOT/'manifest.json',ROOT/'SHA256SUMS']
zip_path=ROOT/'downloads/gerber-layer-checks-teaching-v1.zip'
with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in files:
  info=zipfile.ZipInfo(str(p.relative_to(ROOT)),date_time=(2026,10,4,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o644<<16;z.writestr(info,p.read_bytes())
with zipfile.ZipFile(zip_path) as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(files)
 assert all(sha(z.read(f['path']))==f['sha256'] for f in manifest['files'])
receipt={'result':'PASS','zip':str(zip_path.relative_to(ROOT)),'bytes':zip_path.stat().st_size,'sha256':sha(zip_path.read_bytes()),'members':len(files),'manifestFiles':len(manifest['files']),'crcValid':True,'memberHashesVerified':True,'copiedProductionParserIncluded':False,'copiedProductionHtmlIncluded':False,'publicPublicationStatus':'NOT_PUBLISHED'}
(ROOT/'evidence/delivery-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
