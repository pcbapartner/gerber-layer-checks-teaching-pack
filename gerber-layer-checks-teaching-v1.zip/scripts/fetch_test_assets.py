"""Optional: fetch the exact recorded public parser/classifier for static replay.
No production writes, authentication, webpage scripts or analytics are executed.
Refuse changed bytes instead of silently validating against a different version.
"""
from pathlib import Path
from urllib.request import Request,urlopen
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
assets=json.loads((ROOT/'evidence/test-asset-pins.json').read_text())['assets']
out=ROOT/'evidence/public-code';out.mkdir(parents=True,exist_ok=True)
for asset in assets:
 with urlopen(Request(asset['url'],headers={'User-Agent':'PCBA-Partner-resource-compatibility-check'}),timeout=25) as response:
  if response.status!=200:raise SystemExit('Expected HTTP 200: '+asset['url'])
  data=response.read()
 actual=hashlib.sha256(data).hexdigest()
 if actual!=asset['sha256']:raise SystemExit('Recorded version has changed; do not overwrite evidence: '+asset['file'])
 (out/asset['file']).write_bytes(data)
 print(asset['file'],actual)
