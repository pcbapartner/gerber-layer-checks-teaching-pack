import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {Worker} from 'node:worker_threads';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const code=path.join(root,'evidence/public-code');
const workerPath=path.join(code,'gerber-local-worker.js');
const {classifyGerberLayer:classify}=await import(pathToFileURL(path.join(code,'viewer-tools.mjs')));
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
function render(input){return new Promise((resolve,reject)=>{
 const script=`const {parentPort}=require('node:worker_threads');global.self={postMessage:m=>parentPort.postMessage(m),importScripts:url=>{throw Error('Unexpected external parser '+url);}};require(${JSON.stringify(workerPath)});parentPort.on('message',data=>self.onmessage({data}));`;
 const w=new Worker(script,{eval:true});
 const t=setTimeout(()=>{w.terminate();reject(Error('Worker timeout'));},15000);
 w.on('error',e=>{clearTimeout(t);w.terminate();reject(e);});
 w.on('message',m=>{if(m.progress)return;clearTimeout(t);w.terminate();resolve(m);});w.postMessage(input);
});}
const expectations=JSON.parse(fs.readFileSync(path.join(root,'scenario-expectations.json')));
const inventory=JSON.parse(fs.readFileSync(path.join(root,'scenario-manifest.json')));
const checks=[];const observations=[];
const check=(name,ok,detail)=>checks.push({name,pass:!!ok,...(detail===undefined?{}:{detail})});
for(const expected of expectations.scenarios){
 const id=expected.id,dir=path.join(root,'scenarios',id),files=fs.readdirSync(dir).sort();
 const zip=path.join(root,'downloads',id+'.zip');
 const inv=inventory.scenarios.find(x=>x.id===id);
 check(id+':zip_hash',sha(fs.readFileSync(zip))===inv.zip_sha256);
 for(const f of inv.files)check(id+':bytes:'+f.name,sha(fs.readFileSync(path.join(dir,f.name)))===f.sha256);
 const gerbers=files.filter(n=>n!=='README.txt'&&n!=='LICENSE.txt'&&!n.endsWith('.gbrjob'));
 const info=gerbers.map(name=>{const text=fs.readFileSync(path.join(dir,name),'utf8');const x2=text.match(/%TF\.FileFunction,([^*]+)\*%/)?.[1]||null;const metadataType=x2?.startsWith('Copper,')?(x2.endsWith(',Top')?'COPPER_TOP':x2.endsWith(',Bot')?'COPPER_BOTTOM':'COPPER_INNER'):x2?.startsWith('Profile,')?'OUTLINE':null;return{name,filenameType:classify(name),x2FileFunction:x2,metadataType,filenameMetadataConflict:!!metadataType&&classify(name)!==metadataType};});
 check(id+':gerber_layer_count',gerbers.length===expected.expected.gerber_layer_count);
 check(id+':filename_x2_conflicts',info.filter(x=>x.filenameMetadataConflict).length===expected.expected.filename_x2_conflicts);
 check(id+':x2_bottom_copper_files',info.filter(x=>x.metadataType==='COPPER_BOTTOM').length===expected.expected.x2_bottom_copper_files);
 check(id+':filename_top_copper_files',info.filter(x=>x.filenameType==='COPPER_TOP').length===expected.expected.filename_top_copper_files);
 check(id+':filename_bottom_copper_files',info.filter(x=>x.filenameType==='COPPER_BOTTOM').length===expected.expected.filename_bottom_copper_files);
 const input=[{name:path.basename(zip),bytes:fs.readFileSync(zip)}];let r=await render(input);let selection=null;
 if(r.result?.choices){selection={choices:r.result.choices,defaultSelection:r.result.defaultSelection,selectable:r.result.selectable};r=await render({files:input,selection:r.result.defaultSelection});}
 check(id+':worker_parse_success',!!r.result?.layers,r.error||null);
 if(!r.result?.layers)throw Error(id+': '+r.error);
 const result=r.result;
 check(id+':rendered_layer_count',result.layers.length===expected.expected.gerber_layer_count);
 const outlines=result.layers.filter(l=>classify(l.name)==='OUTLINE'&&l.outline);
 check(id+':outline_count',outlines.length===expected.expected.outline_file_count);
 const dims=outlines.length===1?outlines[0].outline:null;
 check(id+':outline_dimensions',JSON.stringify(dims)===JSON.stringify(expected.expected.closed_outline_centerline_mm),dims);
 check(id+':selection_prompt',!!selection===expected.expected.zip_may_prompt_selection);
 const svgDir=path.join(root,'evidence/static-renders',id);fs.mkdirSync(svgDir,{recursive:true});
 for(const layer of result.layers)fs.writeFileSync(path.join(svgDir,layer.name+'.svg'),layer.svg);
 observations.push({id,selectionPrompt:!!selection,selection,filenameAndMetadata:info,outlineCenterlineMm:dims,renderedLayers:result.layers.map(({name,units,sourceFormat,counts,plotted,outline,warnings,warningCount,compatibility,svg})=>({name,filenameType:classify(name),units,sourceFormat,counts,plotted,outline,warnings,warningCount,compatibility,svgSha256:sha(svg)})),skipped:result.skipped,skippedDetails:result.skippedDetails,scope:'Actual captured production parser and classifier in Node worker_threads. Not DOM rendering or browser interaction acceptance.'});
}
// Check controlled mutations against frozen native output bytes.
const snapshot=path.join(root,'source-snapshot/gerber');const sourceFiles=fs.readdirSync(snapshot).sort();
check('original_all_native_export_files_byte_identical',sourceFiles.every(n=>sha(fs.readFileSync(path.join(snapshot,n)))===sha(fs.readFileSync(path.join(root,'scenarios/01-original-export',n)))));
const outline='pcba-partner-file-interop-teaching-Edge_Cuts.gm1',bottom='pcba-partner-file-interop-teaching-B_Cu.gbl';
check('missing_outline_only_one_export_file_removed',!fs.existsSync(path.join(root,'scenarios/02-missing-outline',outline))&&sourceFiles.filter(n=>n!==outline).every(n=>sha(fs.readFileSync(path.join(snapshot,n)))===sha(fs.readFileSync(path.join(root,'scenarios/02-missing-outline',n)))));
check('conflict_only_renames_bottom_copper_bytes_unchanged',!fs.existsSync(path.join(root,'scenarios/03-filename-x2-conflict',bottom))&&sourceFiles.every(n=>sha(fs.readFileSync(path.join(snapshot,n)))===sha(fs.readFileSync(path.join(root,'scenarios/03-filename-x2-conflict',n===bottom?'misleading-F_Cu.gtl':n)))));
const result={checkedAt:new Date().toISOString(),result:checks.every(c=>c.pass)?'PASS':'FAIL',checks,observations,productionCode:{workerSha256:sha(fs.readFileSync(workerPath)),classifierSha256:sha(fs.readFileSync(path.join(code,'viewer-tools.mjs')))},browserUiVerified:false,manufacturingReady:false,scope:'Three controlled teaching fixtures; static production parser/classifier execution only. No production file changes or external submission.'};
fs.writeFileSync(path.join(root,'evidence/static-validation.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({result:result.result,checks:checks.length,passed:checks.filter(c=>c.pass).length,failed:checks.filter(c=>!c.pass),observations:observations.map(x=>({id:x.id,renderedLayers:x.renderedLayers.length,outline:x.outlineCenterlineMm,selection:x.selectionPrompt,conflicts:x.filenameAndMetadata.filter(i=>i.filenameMetadataConflict)}))},null,2));
process.exitCode=result.result==='PASS'?0:1;
