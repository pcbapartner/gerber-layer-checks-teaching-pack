from pathlib import Path
import hashlib,json,re,struct
from datetime import datetime
from zoneinfo import ZoneInfo
ROOT=Path(__file__).resolve().parents[1]
checks=[];records=[]
def check(name,passed):checks.append({'name':name,'pass':bool(passed)})
cases=[('original',9,81),('missing-outline',8,74),('filename-x2-conflict',9,81)]
for name,layers,warnings in cases:
 textpath=ROOT/'evidence'/('browser-'+name+'.txt');pngpath=textpath.with_suffix('.png')
 if not pngpath.exists():pngpath=textpath.with_suffix('.jpg')
 text=textpath.read_text();b=pngpath.read_bytes()
 if b.startswith(b'\xff\xd8'):
  image_format='JPEG';i=2;dimensions=None
  while i<len(b):
   if b[i]!=255:i+=1;continue
   while b[i]==255:i+=1
   marker=b[i];i+=1
   if marker in [0xd8,0xd9]:continue
   length=int.from_bytes(b[i:i+2],'big')
   if marker in [0xc0,0xc1,0xc2,0xc3,0xc5,0xc6,0xc7,0xc9,0xca,0xcb,0xcd,0xce,0xcf]:
    dimensions=[int.from_bytes(b[i+5:i+7],'big'),int.from_bytes(b[i+3:i+5],'big')];break
   i+=length
  canonical=pngpath.with_suffix('.jpg');canonical.write_bytes(b)
 else:
  image_format='PNG' if b[:8]==b'\x89PNG\r\n\x1a\n' else 'UNKNOWN';dimensions=list(struct.unpack('>II',b[16:24])) if image_format=='PNG' else None;canonical=pngpath
 check(name+':valid_image_format',image_format in ['JPEG','PNG'] and dimensions is not None)
 check(name+':readable_screenshot_size',dimensions is not None and dimensions[0]>800 and dimensions[1]>500)
 check(name+':loaded_layer_count',f'Loaded {layers} layer files' in text)
 check(name+':warning_count',f'{layers} layers · {warnings} parser warnings' in text)
 check(name+':locally_rendered_drawing', 'Locally rendered Gerber and Excellon layers' in text)
 if name=='missing-outline':
  check(name+':explicit_unconfirmed_board_size','Board size unconfirmed: no closed outline verified. Full drawing bounds are not board dimensions.' in text)
  check(name+':no_outline_layer', 'Show Board outline ·' not in text)
  check(name+':no_confirmed_outline_dimensions','Board outline bounds:' not in text)
 else:
  check(name+':confirmed_teaching_outline','Board outline bounds: 35.000 × 25.000 mm' in text)
  check(name+':outline_layer_present','Show Board outline ·' in text)
 if name=='filename-x2-conflict':
  check(name+':misleading_file_labelled_top','strong: Top copper · misleading-F_Cu.gtl' in text)
  check(name+':two_top_copper_labels',len(re.findall(r'- strong: Top copper ·',text))==2)
  check(name+':all_nine_selected_after_choice','Selected 9 files; drawn 9 layers; skipped 0 files.' in text)
 records.append({'scenario':name,'domEvidence':str(textpath.relative_to(ROOT)),'domSha256':hashlib.sha256(textpath.read_bytes()).hexdigest(),'screenshot':str(canonical.relative_to(ROOT)),'originalCapturedFilename':str(pngpath.relative_to(ROOT)),'actualImageFormat':image_format,'screenshotSha256':hashlib.sha256(b).hexdigest(),'screenshotPixels':dimensions,'visualInspection':'Independently viewed by packaging agent. '+('Lower drawing area, 35 x 25 mm parsed outline, 81 warnings and limitation text are readable. Screenshot does not include the top-copper row; that label is verified in DOM.' if name=='filename-x2-conflict' else 'Desktop header, loading controls, 2D mode and loaded '+str(layers)+'-layer status are readable. Screenshot crops most drawing and lower dimensions; those claims are from DOM and static checks, not this screenshot.')})
result={'checkedAt':datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(timespec='seconds'),'result':'PASS' if all(c['pass'] for c in checks) else 'FAIL','checks':checks,'scenarios':records,'browserUiVerified':True,'uiExecutor':'Root task, live production viewer with local teaching ZIPs','reviewMethod':'Independent DOM-content checks and direct visual inspection of all three supplied PNGs','scope':'Three desktop 2D ZIP loading outcomes and reported layers/dimensions/labels; not a complete viewer interaction audit, 3D validation, physical-device check or manufacturing approval.','captureFormatNote':'The three files were supplied with .png names but contain JPEG bytes. Exact-byte .jpg aliases are used in delivery; originals are preserved. No pixel conversion was performed.','publicationStatus':'NOT_PUBLISHED','externalSubmissionStatus':'NOT_SUBMITTED'}
(ROOT/'evidence/browser-validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'result':result['result'],'passed':sum(c['pass'] for c in checks),'total':len(checks)},ensure_ascii=False))
raise SystemExit(0 if result['result']=='PASS' else 1)
