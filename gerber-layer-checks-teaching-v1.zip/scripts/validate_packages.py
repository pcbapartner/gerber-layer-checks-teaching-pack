from pathlib import Path
import hashlib,json,subprocess,sys,zipfile
from datetime import datetime
from zoneinfo import ZoneInfo
ROOT=Path(__file__).resolve().parents[1]
sha=lambda b:hashlib.sha256(b).hexdigest()
checks=[]
def check(name,ok,detail=None):checks.append({'name':name,'pass':bool(ok),**({'detail':detail} if detail is not None else {})})
inventory=json.loads((ROOT/'scenario-manifest.json').read_text())
prior={s['id']:sha((ROOT/s['zip']).read_bytes()) for s in inventory['scenarios']}
# Rebuild from the captured bytes to verify deterministic archives.
subprocess.run([sys.executable,str(ROOT/'scripts/build_pack.py')],check=True,capture_output=True,text=True)
for s in inventory['scenarios']:
 p=ROOT/s['zip'];check(s['id']+':deterministic_zip_bytes',sha(p.read_bytes())==prior[s['id']]==s['zip_sha256'])
 with zipfile.ZipFile(p) as z:
  check(s['id']+':crc_valid',z.testzip() is None)
  check(s['id']+':members_exact',z.namelist()==[f['name'] for f in s['files']])
  check(s['id']+':safe_flat_names',all('/' not in n and '\\' not in n and n not in ('.','..') for n in z.namelist()))
  check(s['id']+':manifest_hashes',all(sha(z.read(f['name']))==f['sha256'] for f in s['files']))
  check(s['id']+':license_and_scope_present',b'MIT License' in z.read('LICENSE.txt') and b'Not for fabrication' in z.read('README.txt'))
 job=next((ROOT/'scenarios'/s['id']).glob('*.gbrjob'))
 paths=[f['Path'] for f in json.loads(job.read_text())['FilesAttributes']]
 missing=[n for n in paths if not(job.parent/n).exists()]
 expected=[] if s['id']=='01-original-export' else ['pcba-partner-file-interop-teaching-Edge_Cuts.gm1'] if s['id']=='02-missing-outline' else ['pcba-partner-file-interop-teaching-B_Cu.gbl']
 check(s['id']+':unedited_job_exposes_expected_missing_path',missing==expected,missing)
provenance=json.loads((ROOT/'source-snapshot/provenance.json').read_text())
source=ROOT.parents[1]/provenance['sourceDirectory']/'exports/gerber'
upstream_available=source.exists()
if upstream_available:
 now_hashes={p.name:sha(p.read_bytes()) for p in sorted(source.iterdir()) if p.is_file()}
 check('upstream_native_exports_still_match_frozen_snapshot',now_hashes==provenance['gerberSha256'])
else:
 frozen_hashes={p.name:sha(p.read_bytes()) for p in sorted((ROOT/'source-snapshot/gerber').iterdir()) if p.is_file()}
 check('frozen_native_exports_match_capture_hashes',frozen_hashes==provenance['gerberSha256'])
check('static_validator_pass',json.loads((ROOT/'evidence/static-validation.json').read_text())['result']=='PASS')
result={'checkedAt':datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(timespec='seconds'),'result':'PASS' if all(c['pass'] for c in checks) else 'FAIL','checks':checks,'noUpstreamFilesWritten':True,'productionChanges':0,'externalSubmissions':0,'scopeOfThisScript':'Archive and source integrity only; browser evidence is separate.','upstreamSourceAvailableForCurrentComparison':upstream_available,'sourceSnapshotCapturedAt':provenance['capturedAt'],'boundary':'Reproducible archives and static-parser evidence only. UI and publishing acceptance are separate.'}
(ROOT/'evidence/package-validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'result':result['result'],'checks':len(checks),'passed':sum(c['pass'] for c in checks),'failed':[c for c in checks if not c['pass']]},ensure_ascii=False))
raise SystemExit(0 if result['result']=='PASS' else 1)
