from pathlib import Path
import hashlib,json,re,shutil,zipfile
from datetime import datetime
from zoneinfo import ZoneInfo

ROOT=Path(__file__).resolve().parents[1]
WORKSPACE=ROOT.parents[1]
SOURCE=WORKSPACE/'operations/kicad-compatibility-pack-20261004'
SNAPSHOT=ROOT/'source-snapshot'
sha=lambda b:hashlib.sha256(b).hexdigest()

# Freeze read-only upstream outputs once; never modify the source package.
if not SNAPSHOT.exists():
 SNAPSHOT.mkdir()
 before={p.name:sha(p.read_bytes()) for p in sorted((SOURCE/'exports/gerber').iterdir()) if p.is_file()}
 (SNAPSHOT/'gerber').mkdir()
 for p in sorted((SOURCE/'exports/gerber').iterdir()):
  if p.is_file():shutil.copyfile(p,SNAPSHOT/'gerber'/p.name)
 for src,dst in [('LICENSE','LICENSE'),('RIGHTS-AND-LIMITS.md','upstream-rights-and-limits.md'),('evidence/commands.json','native-export-commands.json'),('expected/independent-expectations.json','independent-source-expectations.json')]:
  shutil.copyfile(SOURCE/src,SNAPSHOT/dst)
 after={p.name:sha(p.read_bytes()) for p in sorted((SOURCE/'exports/gerber').iterdir()) if p.is_file()}
 copied={p.name:sha(p.read_bytes()) for p in sorted((SNAPSHOT/'gerber').iterdir()) if p.is_file()}
 if not(before==after==copied):raise SystemExit('Source changed during snapshot; inspect before using files')
 (SNAPSHOT/'provenance.json').write_text(json.dumps({'capturedAt':datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(timespec='seconds'),'sourceDirectory':str(SOURCE.relative_to(WORKSPACE)),'originality':'Newly authored synthetic teaching geometry; no functional circuit, client data or copied library footprint. Native KiCad 10.0.6 exporter output.','sourceUntouchedDuringCapture':True,'gerberSha256':before},ensure_ascii=False,indent=2)+'\n')

files={p.name:p.read_bytes() for p in sorted((SNAPSHOT/'gerber').iterdir()) if p.is_file()}
outline='pcba-partner-file-interop-teaching-Edge_Cuts.gm1'
bottom='pcba-partner-file-interop-teaching-B_Cu.gbl'
misnamed='misleading-F_Cu.gtl'
assert outline in files and bottom in files
assert b'%TF.FileFunction,Copper,L2,Bot*%' in files[bottom]
assert b'%TF.FileFunction,Profile,NP*%' in files[outline]
scenarios=[
 {'id':'01-original-export','title':'Unmodified original KiCad export','files':files,'change':'None. All 10 files from the captured export folder retain original names and bytes.','expected':{'export_file_count':10,'gerber_layer_count':9,'outline_file_count':1,'closed_outline_centerline_mm':[35,25],'filename_x2_conflicts':0,'x2_bottom_copper_files':1,'filename_top_copper_files':1,'filename_bottom_copper_files':1,'zip_may_prompt_selection':False,'learning':'A successful render and recognized outline do not validate electrical function, fabrication or assembly.'}},
 {'id':'02-missing-outline','title':'Outline file removed from a copy','files':{n:b for n,b in files.items() if n!=outline},'change':'Remove only '+outline+'. All retained export bytes are unchanged, including the original job file.','expected':{'export_file_count':9,'gerber_layer_count':8,'outline_file_count':0,'closed_outline_centerline_mm':None,'filename_x2_conflicts':0,'x2_bottom_copper_files':1,'filename_top_copper_files':1,'filename_bottom_copper_files':1,'zip_may_prompt_selection':False,'learning':'Copper/paste/mask/silkscreen can still render. Full drawing bounds must not be reported as confirmed board dimensions. The unedited job file still references the removed outline.'}},
 {'id':'03-filename-x2-conflict','title':'Bottom copper disguised as a top copper filename','files':{(misnamed if n==bottom else n):b for n,b in files.items()},'change':'Rename only '+bottom+' to '+misnamed+'. Its byte content and X2 Copper,L2,Bot metadata remain unchanged. The original real top-copper file remains.','expected':{'export_file_count':10,'gerber_layer_count':9,'outline_file_count':1,'closed_outline_centerline_mm':[35,25],'filename_x2_conflicts':1,'x2_bottom_copper_files':1,'filename_top_copper_files':2,'filename_bottom_copper_files':0,'zip_may_prompt_selection':True,'learning':'Filename classification conflicts with X2 content. The current captured viewer classifies by extension/name, so it can label both copper files as top copper. This is an intentional limitation demonstration, not an expected automatic metadata warning. Duplicate .gtl files can trigger file selection; select both deliberately to reproduce.'}}
]
(ROOT/'scenarios').mkdir(exist_ok=True);(ROOT/'downloads').mkdir(exist_ok=True)
license_text=(SNAPSHOT/'LICENSE').read_text()
expected=[];inventory=[]
for s in scenarios:
 d=ROOT/'scenarios'/s['id'];d.mkdir(exist_ok=True)
 for old in d.iterdir():
  if old.is_file():old.unlink()
 for n,b in s['files'].items():(d/n).write_bytes(b)
 text=(s['title']+'\n\n'+s['change']+'\n\n'+s['expected']['learning']+'\n\nOriginal non-functional synthetic teaching data. Not for fabrication, procurement or assembly. There are no routed nets or validated real footprints. All-SMD geometry; no drill files are expected. Created for PCBA Partner with AI assistance, licensed under the accompanying MIT license.\n\nSee the main pack README and scenario-expectations.json for provenance, exact expected results and test scope. Public publication and third-party listing are not implied.\n')
 (d/'README.txt').write_text(text);(d/'LICENSE.txt').write_text(license_text)
 z=ROOT/'downloads'/(s['id']+'.zip')
 with zipfile.ZipFile(z,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as a:
  for p in sorted(d.iterdir()):
   info=zipfile.ZipInfo(p.name,date_time=(2026,10,4,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o644<<16;a.writestr(info,p.read_bytes())
 expected.append({k:v for k,v in s.items() if k!='files'})
 inventory.append({'id':s['id'],'zip':'downloads/'+z.name,'zip_sha256':sha(z.read_bytes()),'files':[{'name':p.name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(d.iterdir())]})
(ROOT/'scenario-expectations.json').write_text(json.dumps({'purpose':'Expected properties specified from the controlled transformations and original teaching geometry; these are separate from observed viewer output.','nativeExporterVersion':'10.0.6','boardGeometry':'35 x 25 mm non-functional rectangular teaching PCB','manufacturingReady':False,'scenarios':expected},ensure_ascii=False,indent=2)+'\n')
(ROOT/'scenario-manifest.json').write_text(json.dumps({'scenarios':inventory},ensure_ascii=False,indent=2)+'\n')
(ROOT/'LICENSE').write_text(license_text)
print(json.dumps({'scenarioCount':len(inventory),'zipFiles':[i['zip'] for i in inventory]},indent=2))
