# Gerber layer checks: three controlled teaching examples

This pack demonstrates two file-package problems using actual, unedited KiCad
10.0.6 Gerber exports from an original synthetic teaching board. It is a
non-functional geometry exercise, not a fabrication or assembly release.

**Status: local package and three live-browser 2D scenarios verified; not published
and not submitted to a third-party listing.**

The complete bundle `downloads/gerber-layer-checks-teaching-v1.zip` (a workspace
delivery file, not nested inside itself) includes the three example ZIPs, original teaching source, explanations, recorded
results and reproducibility scripts. It excludes copied production parser code.

| Download | Controlled change | Expected observation |
|---|---|---|
| [01-original-export.zip](downloads/01-original-export.zip) | None: all 10 native export files retain their names and bytes | Nine drawable layers; one closed 35 × 25 mm outline |
| [02-missing-outline.zip](downloads/02-missing-outline.zip) | Only the `Edge_Cuts.gm1` file is removed | Eight layers can still draw, but board dimensions are unconfirmed |
| [03-filename-x2-conflict.zip](downloads/03-filename-x2-conflict.zip) | The bottom-copper file is renamed to `misleading-F_Cu.gtl`; every file's content is retained | Two `.gtl` names suggest top copper; the renamed file still declares `Copper,L2,Bot` in X2 metadata |

Each ZIP includes its own short explanation and MIT license. The original
`.gbrjob` is deliberately left unchanged in every case. In the two faulty cases
it still references the removed or renamed file. A viewer ignoring job metadata
can therefore draw a package whose manifest and files disagree.

## What to inspect

Open one ZIP at a time in the [PCBA Partner Gerber viewer](https://pcbapartner.com/gerber-viewer.html).

1. Start with the original export. Inspect top/bottom copper and the outline
   separately. The expected outline centerline rectangle is 35 × 25 mm. The
   0.05 mm outline stroke can make a full drawing/job bounding box 35.05 ×
   25.05 mm; this is not an extra 0.05 mm of validated physical board material.
2. Open the missing-outline case. Copper and silkscreen can look plausible, but
   no outline file is supplied. Do not substitute the combined graphics bounds
   for a confirmed board size. Check file presence against the job metadata.
3. Open the filename-conflict case. The two `.gtl` files may open a file-selection
   step; select both intentionally. Compare the filename with the line
   `%TF.FileFunction,Copper,L2,Bot*%` in `misleading-F_Cu.gtl`. Renaming changed
   neither the layer's geometry nor its bottom-copper metadata.

The current captured viewer uses filename/extension classification. It can label
this renamed bottom-copper file as top copper. **The conflict is a manual or
independent metadata check in this exercise, not a promised automatic warning.**
Use a text editor or the included validator to compare the content with the name.
A successful load is not proof that the package is consistent.

## Recorded checks and limitations

On 2026-10-04 the public parser and filename classifier were downloaded from the
live viewer's script references and executed with these ZIPs in Node workers.
The static validation passed **71/71 checks**:

| Case | Drawn layers | Parsed outline centerline | File selection | Parser warnings |
|---|---:|---|---|---:|
| Original | 9 | 35 × 25 mm | No | 81 |
| Missing outline | 8 | None | No | 74 |
| Filename/X2 conflict | 9 | 35 × 25 mm | Yes | 81 |

These warnings report ignored X2 attribute blocks such as `TF`, `TA`, and `TD`,
including `FileFunction` and `FilePolarity`. They are retained in the evidence,
not suppressed. The result proves that the captured parser produces drawing
objects for these fixtures and that the controlled discrepancies are detectable;
it does not establish complete X2 support, copper/polarity fidelity, or a
manufacturing-quality check. The independent filename/metadata comparison covers
copper side and profile classification only.

The main task subsequently loaded all three ZIPs in the live desktop viewer.
Saved DOM evidence confirms the original nine-layer/35 × 25 mm result, the
missing-outline eight-layer result with an explicit unconfirmed-board-size
message, and the renamed bottom-copper file displayed as top copper alongside
the true top-copper file. Its selected nine layers and 81 warnings were visible.
Independent review of all three screenshots and DOM extracts passed 25/25 checks.

The first two screenshots show the desktop controls and load state, with most of
the drawing and dimensions below the captured viewport; those lower observations
are supported by DOM evidence. The third image shows part of the teaching drawing,
outline dimensions and warning count. The original captures had `.png` filenames
but JPEG bytes; exact-byte `.jpg` copies are supplied without pixel conversion.

This verifies the three desktop 2D loading outcomes, not every viewer control,
3D, a physical device, a CAM system, or manufacturing. No website deployment,
external submission, public backlink or manufacturing outcome has been created
by this pack. See `evidence/browser-validation.json` and `STATUS.json`.

## Contents and reproduction

- `source-snapshot/`: frozen native output bytes, seven original KiCad source
  files, the Gerber export command, original expectations, reuse terms and hashes.
  Local KiCad display-state files are excluded.
- `scenarios/`: expanded ZIP contents; original bytes plus controlled omissions
  or filename changes and explanatory documents.
- `scenario-expectations.json`: expected results defined from the source geometry
  and transformations, separately from observed parser output.
- `scenario-manifest.json`: ZIP and expanded-file SHA-256 checksums.
- `evidence/static-validation.json`: checks, warnings, observed layer classification,
  and parser/classifier hashes.
- `evidence/static-renders/`: SVGs produced by the captured parser. These are
  parser outputs, not screenshots or independent geometric-fidelity approval.
- `evidence/browser-*.txt` and `.jpg`: live desktop DOM captures and screenshots.
- `evidence/public-code/`: internal verification copies of live scripts; excluded
  from both the example ZIPs and complete delivery ZIP. Exact asset pins and an
  optional fetching script allow a deliberate replay without redistributing them.

From this pack's folder, with Python 3 installed:

```sh
python3 scripts/build_pack.py
python3 scripts/validate_packages.py
python3 scripts/verify_browser_evidence.py
```

These commands reproduce archives and verify the saved evidence; they do not
create a fresh browser capture. To replay the static parser test, install Node,
then explicitly fetch the two exact public asset versions (their recorded hashes
must match):

```sh
python3 scripts/fetch_test_assets.py
node scripts/validate_scenarios.mjs
```

If those public bytes are no longer available, retain the recorded result and
report that replay limitation; do not substitute a different parser silently.

The build script uses the frozen snapshot once it exists and intentionally
replaces only this pack's generated scenario folders and ZIPs. ZIP member order
and timestamps are fixed so the same captured source and documentation reproduce
the same ZIP hashes. It never regenerates or edits the upstream KiCad package.
To reproduce the actual KiCad export, use `source-snapshot/native-source/` and
`source-snapshot/native-gerber-export-command.json` with KiCad CLI 10.0.6. Adapt
the recorded relative input/output paths to a separate working folder; leave the
frozen snapshot intact. A fresh export may have new embedded timestamps while
preserving the same geometry.

## Origin and rights

All teaching geometry was newly authored for PCBA Partner with AI assistance.
There is no customer PCB, third-party product, copied stock footprint, or retained
editorial article in these examples. The original source package and this teaching
content use the included MIT license. KiCad and any captured third-party software
retain their own licenses; no endorsement is implied. See
[RIGHTS-AND-LIMITS.md](RIGHTS-AND-LIMITS.md).
