# Provenance and reuse

The schematic, symbol, PCB, fictional two-pad footprint, coordinates, teaching
identifiers, expectation table, and scripts in this package were newly authored
for PCBA Partner on 2026-10-04 with AI assistance. They do not reproduce a client
design, third-party board, real supplier part, proprietary product, or earlier
submitted editorial article. Only basic rectangles, two passive pins, and two
square pads are used. No KiCad stock library footprint or symbol was copied.

The source files were generated as KiCad-format text by the included script
(`generator = pcba_partner_teaching_fixture`), then consumed by the installed
KiCad CLI 10.0.6. The files in `exports/` are actual, unedited outputs of that CLI.
This distinction matters: the sources are a synthetic teaching design, while the
export files are real KiCad exporter output.

The new original package content is offered under the included MIT license.
KiCad itself, its documentation, and its trademarks retain their respective
licenses and ownership. No KiCad endorsement or official listing is implied.

`DEMO-*` strings are deliberately fictional test identifiers. They are not MPNs
that can be bought, fitted, or approved. `Teaching:TwoPad` is not a land pattern
for any actual resistor, capacitor, connector, IC, or diode. Reference prefixes
and value labels are chosen to exercise file fields only.

# Validation boundaries

- Six references and one repeated BOM group exercise a small set of exporter
  structures, coordinates, units, front/back sides, and rotation values.
- There are no routed electrical nets and no functional circuit. No electrical
  simulation, functional test, real board, manufacturing, assembly, or physical
  measurement has been performed.
- A 35 × 25 mm rectangle is supplied for viewer context. Gerber output is a
  teaching resource and is not a fabrication release; no drill data is expected
  for this all-SMD fictional geometry.
- Export rotation consistency does not establish machine-specific placement
  angle, bottom-side mirroring, pick-and-place origin, or nozzle conventions.
- Only the recorded KiCad version and explicit options are evidenced. This is
  not a promise of compatibility with all KiCad versions, project variants,
  unicode fields, CSV quoting cases, multi-unit symbols, DNP policies, or boards.
- A successful native-export check does not itself establish PCBA Partner web
  tool compatibility. The web tools require a separate, recorded check.
- No public resource listing, accepted contribution, external link, or SEO
  outcome has been created by preparing these files.
